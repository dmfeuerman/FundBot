#!/bin/sh
sudo pip3 install lxml
sudo pip3 install pandas
sudo pip3 install xlsxwriter
sudo pip3 install requests
sudo pip3 install openpyxl

